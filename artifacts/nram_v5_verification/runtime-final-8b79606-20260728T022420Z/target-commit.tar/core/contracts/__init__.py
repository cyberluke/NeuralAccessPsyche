"""Engine contracts for NeuralAccessPsyche."""
