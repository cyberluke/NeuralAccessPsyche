"""Engine abstractions."""
