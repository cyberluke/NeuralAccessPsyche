"""NRAM controller package."""
