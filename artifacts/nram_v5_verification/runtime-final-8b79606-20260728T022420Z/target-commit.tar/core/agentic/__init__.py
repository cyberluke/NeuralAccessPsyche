"""Agentic innovation pipeline package."""
