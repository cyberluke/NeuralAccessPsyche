"""Agentic personas package."""
