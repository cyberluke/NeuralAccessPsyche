{pkgs}: {
  deps = [
    pkgs.libxcrypt
  ];
}
